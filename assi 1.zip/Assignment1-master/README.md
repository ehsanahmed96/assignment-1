# Assignment1
here the three classical  ciphers 
  1- AFFine cipher  you can find its encrayption and decryption 
  2- shift cipher you can find its encrayption and decryption
  3- vigenere-cipher you can find its encrayption and decryption
  4 - you have to run using cmd  and especify the paramters 
  5 - create the input file and put the plaintext in it
     and you will get the cipher text in a file called output.txt
     
